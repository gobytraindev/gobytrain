export default function Home() {
  return (
    <div style={{ fontFamily: 'sans-serif', textAlign: 'center', marginTop: '4rem' }}>
      <h1>Welcome to Gobytrain</h1>
      <p>Your train journey starts here.</p>
    </div>
  );
}